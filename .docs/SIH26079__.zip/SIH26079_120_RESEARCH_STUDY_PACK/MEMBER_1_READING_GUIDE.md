# Member 1 Reading Guide

**Role:** project, weather-science, and first-literature presenter  
**Fixed allocation:** Files 001–022 (22 files).

## Assigned files

| ID | Topic | Prerequisites | Suggested order |
|---|---|---|---|
| 001 | [Project mission and scope](001_project_mission_and_scope.md) | none | 1 |
| 002 | [Problem-statement interpretation and missing-verbatim-text caveat](002_problem_statement_interpretation.md) | 001 | 2 |
| 003 | [Stakeholder needs](003_stakeholder_needs.md) | 001 | 3 |
| 004 | [Forecast bust definition](004_forecast_bust_definition.md) | 001 | 4 |
| 005 | [Ordinary error versus uncertainty versus bust](005_ordinary_error_uncertainty_bust.md) | 004 | 5 |
| 006 | [Decision-support boundaries](006_decision_support_boundaries.md) | 001,004 | 6 |
| 007 | [Public-proxy versus NCMRWF validation boundary](007_public_proxy_vs_ncmrwf.md) | 001 | 7 |
| 008 | [Project evidence labels](008_evidence_labels.md) | 001 | 8 |
| 009 | [Terminology glossary](009_terminology_glossary.md) | 001,004,008 | 9 |
| 010 | [Project story and one-sentence pitch](010_project_story_pitch.md) | 001,006,007 | 10 |
| 011 | [Medium-range predictability](011_medium_range_predictability.md) | 001 | 11 |
| 012 | [Chaotic error growth](012_chaotic_error_growth.md) | 011 | 12 |
| 013 | [Ensemble forecasting](013_ensemble_forecasting.md) | 011 | 13 |
| 014 | [ETKF and stochastic physics](014_etkf_stochastic_physics.md) | 013 | 14 |
| 015 | [Ensemble spread and under-dispersion](015_ensemble_spread_underdispersion.md) | 013 | 15 |
| 016 | [Atmospheric regimes](016_atmospheric_regimes.md) | 011 | 16 |
| 017 | [Rossby-wave and transition context](017_rossby_wave_transitions.md) | 016 | 17 |
| 018 | [NCMRWF NEPS configuration and known limits](018_ncmrwf_neps_limits.md) | 007,013 | 18 |
| 019 | [GEFS configuration as prototype input](019_gefs_prototype_input.md) | 007,013 | 19 |
| 020 | [WeatherBench 2 and ERA5 role](020_weatherbench2_era5_role.md) | 007,019 | 20 |
| 021 | [Direct bust-detection precedent from Uno et al.](021_uno_bust_detection.md) | 008,011 | 21 |
| 022 | [Lillo and Parsons error-growth work](022_lillo_parsons_error_growth.md) | 011,012 | 22 |

## Recommended study order

Read the assigned files in numeric order unless a prerequisite is listed. Before team discussion, check the index, record all unverified claims, and do not upgrade targets to results. Each study should produce the handoff named in the file.

## Short daily plan

Day 1: Read the first third of the allocation and record vocabulary and evidence labels.  
Day 2: Read the middle third and complete the practical exercises for the most foundational files.  
Day 3: Read the final third and connect outputs to the next member’s allocation.  
Day 4: Audit claims, dependencies, and the public-proxy/NCMRWF boundary.  
Day 5: Prepare a five-minute presentation and one unresolved question for the team.

## Discussion questions

1. Which statements are confirmed, and which remain literature leads, project decisions, targets, gaps, or future work?
2. Does any planned demo or document imply trained/evaluated performance or NCMRWF operational validation?
3. What evidence does the next member need from this allocation?
4. Which question should enter the shared cross-team question register?

## Concrete team handoff

Provide a concise synthesis for the team covering the project, weather-science, and first-literature presenter, a table of evidence labels, completed exercises, unresolved questions, and links to all assigned files. Member 1 must use the exact terminology and caveats from the package README.
