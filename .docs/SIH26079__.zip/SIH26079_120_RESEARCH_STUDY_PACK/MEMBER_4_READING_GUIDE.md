# Member 4 Reading Guide

**Role:** GBM, calibration, OOD, abstention, explainability, and evaluation presenter  
**Fixed allocation:** Files 067–088 (22 files).

## Assigned files

| ID | Topic | Prerequisites | Suggested order |
|---|---|---|---|
| 067 | [Analog features](067_analog_features.md) | 061,065 | 1 |
| 068 | [Climatology and persistence baselines](068_climatology_persistence_baselines.md) | 054,061 | 2 |
| 069 | [Spread-only and logistic baselines](069_spread_logistic_baselines.md) | 062,068 | 3 |
| 070 | [Calibrated LightGBM/XGBoost core-model decision](070_calibrated_gbm_decision.md) | 061,068,069 | 4 |
| 071 | [Calibration purpose](071_calibration_purpose.md) | 070,024 | 5 |
| 072 | [Platt, isotonic, and beta calibration](072_platt_isotonic_beta.md) | 071 | 6 |
| 073 | [EasyUQ and DRN optional methods](073_easyuq_drn.md) | 070,071 | 7 |
| 074 | [Conformal experiment rules and assumptions](074_conformal_assumptions.md) | 071,072 | 8 |
| 075 | [OOD detection signals](075_ood_signals.md) | 029,067 | 9 |
| 076 | [NORMAL, UNUSUAL, OOD, and ABSTAIN states](076_state_machine.md) | 075 | 10 |
| 077 | [Selective abstention and review burden](077_selective_abstention.md) | 076,081 | 11 |
| 078 | [SHAP and correlational explanations](078_shap_correlational.md) | 070,075 | 12 |
| 079 | [Analog-retrieval safety](079_analog_retrieval_safety.md) | 067,075 | 13 |
| 080 | [Risk bands and human-review policy](080_risk_bands_human_review.md) | 076,077,078,079 | 14 |
| 081 | [WMO/CAWCR quality framework](081_wmo_cawcr_framework.md) | 024 | 15 |
| 082 | [PR-AUC versus ROC-AUC and accuracy](082_prauc_roc_accuracy.md) | 059,068 | 16 |
| 083 | [Brier score and Brier skill](083_brier_score_skill.md) | 071,082 | 17 |
| 084 | [Reliability diagrams, ECE, and calibration slope](084_reliability_ece_slope.md) | 071,072,083 | 18 |
| 085 | [Precision, recall, F1, FAR, and detection rate](085_precision_recall_far_detection.md) | 082,083 | 19 |
| 086 | [Warning lead time](086_warning_lead_time.md) | 042,085 | 20 |
| 087 | [Spatial/object metrics](087_spatial_object_metrics.md) | 058,085 | 21 |
| 088 | [Coverage-risk and retained-case metrics](088_coverage_risk_retained.md) | 074,077,084 | 22 |

## Recommended study order

Read the assigned files in numeric order unless a prerequisite is listed. Before team discussion, check the index, record all unverified claims, and do not upgrade targets to results. Each study should produce the handoff named in the file.

## Short daily plan

Day 1: Read the first third of the allocation and record vocabulary and evidence labels.  
Day 2: Read the middle third and complete the practical exercises for the most foundational files.  
Day 3: Read the final third and connect outputs to the next member’s allocation.  
Day 4: Audit claims, dependencies, and the public-proxy/NCMRWF boundary.  
Day 5: Prepare a five-minute presentation and one unresolved question for the team.

## Discussion questions

1. Which statements are confirmed, and which remain literature leads, project decisions, targets, gaps, or future work?
2. Does any planned demo or document imply trained/evaluated performance or NCMRWF operational validation?
3. What evidence does the next member need from this allocation?
4. Which question should enter the shared cross-team question register?

## Concrete team handoff

Provide a concise synthesis for the team covering the GBM, calibration, OOD, abstention, explainability, and evaluation presenter, a table of evidence labels, completed exercises, unresolved questions, and links to all assigned files. Member 4 must use the exact terminology and caveats from the package README.
