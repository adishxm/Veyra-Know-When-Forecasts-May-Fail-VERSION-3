# Member 5 Reading Guide

**Role:** experiment-proof, backend, API, database, frontend, deployment, and monitoring presenter  
**Fixed allocation:** Files 089–110 (22 files).

## Assigned files

| ID | Topic | Prerequisites | Suggested order |
|---|---|---|---|
| 089 | [Bootstrapped confidence intervals and stratification](089_bootstrap_stratification.md) | 049,085 | 1 |
| 090 | [Experiment ladder and full-model go/no-go rule](090_experiment_ladder_go_no_go.md) | 068,069,070,089 | 2 |
| 091 | [Modular-monolith choice](091_modular_monolith.md) | 001,090 | 3 |
| 092 | [Repository boundaries](092_repository_boundaries.md) | 091 | 4 |
| 093 | [Inference lifecycle](093_inference_lifecycle.md) | 070,076,091 | 5 |
| 094 | [Prediction envelope](094_prediction_envelope.md) | 093 | 6 |
| 095 | [API endpoints](095_api_endpoints.md) | 094 | 7 |
| 096 | [API error contract](096_api_error_contract.md) | 095,076 | 8 |
| 097 | [PostgreSQL entities](097_postgres_entities.md) | 040,094 | 9 |
| 098 | [Object-store references](098_object_store_references.md) | 037,038,097 | 10 |
| 099 | [Model and calibration registry](099_model_calibration_registry.md) | 070,072,094,098 | 11 |
| 100 | [Security, authentication, and audit logging](100_security_auth_audit.md) | 095,097,099 | 12 |
| 101 | [Dashboard information architecture](101_dashboard_information_architecture.md) | 094,100 | 13 |
| 102 | [Map and spatial-product display](102_map_spatial_product.md) | 058,087,101 | 14 |
| 103 | [Risk-trajectory display](103_risk_trajectory_display.md) | 080,101 | 15 |
| 104 | [Explanation and analog UI](104_explanation_analog_ui.md) | 078,079,101 | 16 |
| 105 | [Trust banners and abstention UI](105_trust_banners_abstention_ui.md) | 007,076,080,101 | 17 |
| 106 | [Deterministic historical replay](106_historical_replay.md) | 037,042,094 | 18 |
| 107 | [Live-mode boundaries](107_live_mode_boundaries.md) | 007,105,106 | 19 |
| 108 | [Docker and local setup](108_docker_local_setup.md) | 091,092 | 20 |
| 109 | [Deployment, CI/CD, and rollback](109_deployment_cicd_rollback.md) | 099,108 | 21 |
| 110 | [Monitoring, drift, feedback, and retraining proposal rules](110_monitoring_drift_feedback.md) | 089,099,109 | 22 |

## Recommended study order

Read the assigned files in numeric order unless a prerequisite is listed. Before team discussion, check the index, record all unverified claims, and do not upgrade targets to results. Each study should produce the handoff named in the file.

## Short daily plan

Day 1: Read the first third of the allocation and record vocabulary and evidence labels.  
Day 2: Read the middle third and complete the practical exercises for the most foundational files.  
Day 3: Read the final third and connect outputs to the next member’s allocation.  
Day 4: Audit claims, dependencies, and the public-proxy/NCMRWF boundary.  
Day 5: Prepare a five-minute presentation and one unresolved question for the team.

## Discussion questions

1. Which statements are confirmed, and which remain literature leads, project decisions, targets, gaps, or future work?
2. Does any planned demo or document imply trained/evaluated performance or NCMRWF operational validation?
3. What evidence does the next member need from this allocation?
4. Which question should enter the shared cross-team question register?

## Concrete team handoff

Provide a concise synthesis for the team covering the experiment-proof, backend, API, database, frontend, deployment, and monitoring presenter, a table of evidence labels, completed exercises, unresolved questions, and links to all assigned files. Member 5 must use the exact terminology and caveats from the package README.
