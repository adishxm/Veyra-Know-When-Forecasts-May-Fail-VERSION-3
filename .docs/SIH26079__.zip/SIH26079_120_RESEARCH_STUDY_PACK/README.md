# SIH26079 120 Research Study Pack

## Purpose

This package contains exactly 120 focused internal research briefs for the SIH26079 Forecast-Bust Sentinel project. They are study aids, not 120 invented published papers. Each brief has one narrow topic, a concrete learning objective, an evidence label, a practical exercise, a handoff, and dependencies.

## Source hierarchy and limitation

The requested source hierarchy places `SIH26079_MASTER_PROJECT_DOCUMENTATION_MERGED.md` first, followed by original attachments and archive, verified references, and the completed master documentation. Only the user-supplied specification was available in the workspace for this generation. The named project documents were not available, so every brief preserves that verification gap and does not invent source details.

The non-negotiable boundary is repeated throughout the relevant files: the current project is a public-proxy prototype using GEFS or WeatherBench 2 with ERA5 reference analysis. NCMRWF/NEPS operational validation is future and conditional until paired historical data, metadata, permission, and a verification source are provided. No SIH26079 model training or evaluation result is claimed.

## Evidence labels

| Label | Meaning |
|---|---|
| CONFIRMED | Supported by the available project record or an explicitly verified source. |
| FROM LITERATURE | Literature context that must be traceable to a confirmed reference. |
| PROJECT DECISION | A design or governance rule for SIH26079. |
| UNVERIFIED / GAP | A source, access fact, implementation fact, or empirical claim still needing proof. |
| FUTURE / OUT OF SCOPE | Conditional work beyond the current demonstrated scope. |
| TARGET / ACCEPTANCE GATE | A condition to test or accept later, never an achieved result. |

## Naming, allocation, and use

Research files are numbered continuously from `001_` through `120_`. The master index and support files are not counted. Members 1–5 receive 22 files each; Member 6 receives 10 files plus the coordination role described in the index and guide. Begin with the assigned guide, read prerequisites in order, perform the exercise, and hand off the requested artifact. Use the cross-team question register to resolve gaps rather than silently rewriting them.

The withdrawn Hurricane Michael article is not standing evidence. Any dependency on the IFS data-assimilation PDF must retain the partial-extraction warning. Mentions of conformal prediction must preserve its assumptions caveat. Mentions of SHAP, feature importance, or analogs must say they are correlational or similarity evidence, not causal proof.

## Validation

`QUALITY_CONTROL_REPORT.md` records the generated counts, allocation, mandatory-section checks, caveat checks, and source-traceability limitation. `SOURCE_TO_120_FILE_MAP.csv` maps every file to its available source anchor and evidence label.
