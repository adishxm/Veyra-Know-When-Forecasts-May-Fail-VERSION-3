# Member 6 Reading Guide

**Role:** integration, project-management, demo, viva, future-roadmap, claim-discipline, and documentation-maintenance presenter  
**Fixed allocation:** Files 111–120 (10 files).

## Assigned files

| ID | Topic | Prerequisites | Suggested order |
|---|---|---|---|
| 111 | [Six-member collaboration protocol](111_six_member_protocol.md) | 001,008 | 1 |
| 112 | [Seven-day vertical-slice sprint](112_seven_day_vertical_slice.md) | 090,092,106 | 2 |
| 113 | [Thirty-phase roadmap summary](113_thirty_phase_roadmap.md) | 090,112 | 3 |
| 114 | [Release checklist and acceptance evidence](114_release_checklist.md) | 050,060,090,109 | 4 |
| 115 | [Failure scenarios and safe fallbacks](115_failure_scenarios_fallbacks.md) | 076,096,105 | 5 |
| 116 | [Cost-control plan](116_cost_control.md) | 112,113 | 6 |
| 117 | [Judge demo script](117_judge_demo_script.md) | 010,105,106,114 | 7 |
| 118 | [Viva questions and honest answers](118_viva_questions_answers.md) | 007,030,074,078,107 | 8 |
| 119 | [Future advancement roadmap](119_future_advancement_roadmap.md) | 018,029,073,107,113 | 9 |
| 120 | [Final claim sheet and document-maintenance policy](120_claim_sheet_maintenance.md) | 008,007,114,119 | 10 |

## Recommended study order

Read the assigned files in numeric order unless a prerequisite is listed. Before team discussion, check the index, record all unverified claims, and do not upgrade targets to results. Each study should produce the handoff named in the file.

## Short daily plan

Day 1: Read the first third of the allocation and record vocabulary and evidence labels.  
Day 2: Read the middle third and complete the practical exercises for the most foundational files.  
Day 3: Read the final third and connect outputs to the next member’s allocation.  
Day 4: Audit claims, dependencies, and the public-proxy/NCMRWF boundary.  
Day 5: Prepare a five-minute presentation and one unresolved question for the team.

## Discussion questions

1. Which statements are confirmed, and which remain literature leads, project decisions, targets, gaps, or future work?
2. Does any planned demo or document imply trained/evaluated performance or NCMRWF operational validation?
3. What evidence does the next member need from this allocation?
4. Which question should enter the shared cross-team question register?

## Concrete team handoff

Provide a concise synthesis for the team covering the integration, project-management, demo, viva, future-roadmap, claim-discipline, and documentation-maintenance presenter, a table of evidence labels, completed exercises, unresolved questions, and links to all assigned files. Member 6 must use the exact terminology and caveats from the package README.

## Additional coordination duty

Maintain the cross-team question register, verify that presentations use the public-proxy claim boundary, consolidate unresolved decisions, and run the final release-checklist meeting. This is a coordination role and does not add research files.
