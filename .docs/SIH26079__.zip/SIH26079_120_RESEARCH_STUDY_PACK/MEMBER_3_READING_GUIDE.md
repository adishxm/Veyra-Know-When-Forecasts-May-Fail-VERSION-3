# Member 3 Reading Guide

**Role:** leakage, labeling, feature-engineering, and baseline-model presenter  
**Fixed allocation:** Files 045–066 (22 files).

## Assigned files

| ID | Topic | Prerequisites | Suggested order |
|---|---|---|---|
| 045 | [Missingness and stale-data policy](045_missingness_stale_policy.md) | 041,042,044 | 1 |
| 046 | [Data lifecycle states](046_data_lifecycle_states.md) | 037,045 | 2 |
| 047 | [Allowed issue-time features](047_allowed_issue_time_features.md) | 042,046 | 3 |
| 048 | [Forbidden future features](048_forbidden_future_features.md) | 042,047 | 4 |
| 049 | [Chronological, event, region, and model-version splits](049_splits.md) | 047,048 | 5 |
| 050 | [Leakage unit and integration tests](050_leakage_tests.md) | 047,048,049 | 6 |
| 051 | [Label-engine goals](051_label_engine_goals.md) | 049,050 | 7 |
| 052 | [RMSE and alternative error measures](052_rmse_alternatives.md) | 051 | 8 |
| 053 | [Training-only robust normalization](053_robust_normalization.md) | 050,052 | 9 |
| 054 | [q95 primary label](054_q95_primary_label.md) | 051,052,053 | 10 |
| 055 | [q90/q97.5/q99 sensitivity study](055_q90_q975_q99_sensitivity.md) | 054 | 11 |
| 056 | [Ambiguity and gray-band handling](056_gray_band.md) | 054,055 | 12 |
| 057 | [Severity and continuous targets](057_severity_continuous_targets.md) | 052,054 | 13 |
| 058 | [Spatial displacement and neighborhood/object labels](058_spatial_object_labels.md) | 057 | 14 |
| 059 | [Rare-event class imbalance](059_rare_event_imbalance.md) | 054,055 | 15 |
| 060 | [Label-versioning and reproducibility](060_label_versioning.md) | 051,054,056 | 16 |
| 061 | [Forecast-state features](061_forecast_state_features.md) | 047,053 | 17 |
| 062 | [Ensemble-geometry features](062_ensemble_geometry.md) | 013,047 | 18 |
| 063 | [Cycle-revision features](063_cycle_revision_features.md) | 042,047 | 19 |
| 064 | [Forecast-trajectory divergence](064_trajectory_divergence.md) | 061,063 | 20 |
| 065 | [Regime and monsoon features](065_regime_monsoon_features.md) | 016,047 | 21 |
| 066 | [Multi-model disagreement](066_multi_model_disagreement.md) | 062,065 | 22 |

## Recommended study order

Read the assigned files in numeric order unless a prerequisite is listed. Before team discussion, check the index, record all unverified claims, and do not upgrade targets to results. Each study should produce the handoff named in the file.

## Short daily plan

Day 1: Read the first third of the allocation and record vocabulary and evidence labels.  
Day 2: Read the middle third and complete the practical exercises for the most foundational files.  
Day 3: Read the final third and connect outputs to the next member’s allocation.  
Day 4: Audit claims, dependencies, and the public-proxy/NCMRWF boundary.  
Day 5: Prepare a five-minute presentation and one unresolved question for the team.

## Discussion questions

1. Which statements are confirmed, and which remain literature leads, project decisions, targets, gaps, or future work?
2. Does any planned demo or document imply trained/evaluated performance or NCMRWF operational validation?
3. What evidence does the next member need from this allocation?
4. Which question should enter the shared cross-team question register?

## Concrete team handoff

Provide a concise synthesis for the team covering the leakage, labeling, feature-engineering, and baseline-model presenter, a table of evidence labels, completed exercises, unresolved questions, and links to all assigned files. Member 3 must use the exact terminology and caveats from the package README.
