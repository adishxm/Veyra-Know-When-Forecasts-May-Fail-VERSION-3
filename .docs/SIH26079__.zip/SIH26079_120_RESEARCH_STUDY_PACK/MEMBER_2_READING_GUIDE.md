# Member 2 Reading Guide

**Role:** research-novelty, data-governance, QC, and alignment presenter  
**Fixed allocation:** Files 023–044 (22 files).

## Assigned files

| ID | Topic | Prerequisites | Suggested order |
|---|---|---|---|
| 023 | [NCMRWF evidence review](023_ncmrwf_evidence.md) | 007,018 | 1 |
| 024 | [Verification research](024_verification_research.md) | 011,013 | 2 |
| 025 | [AI weather-model reliability limits](025_ai_weather_reliability.md) | 020 | 3 |
| 026 | [GenCast context](026_gencast_context.md) | 025 | 4 |
| 027 | [Post-hoc calibration evidence](027_posthoc_calibration.md) | 015,024 | 5 |
| 028 | [WeatherBench 2 methodology](028_weatherbench2_methodology.md) | 020,024 | 6 |
| 029 | [OOD and extreme-event research](029_ood_extreme_event_research.md) | 016,025 | 7 |
| 030 | [Defensible novelty and red-team challenges](030_defensible_novelty_red_team.md) | 021,024,029 | 8 |
| 031 | [Data-source decision tree](031_data_source_decision_tree.md) | 019,020 | 9 |
| 032 | [Data cards and licenses](032_data_cards_licenses.md) | 031 | 10 |
| 033 | [GEFS ingestion planning](033_gefs_ingestion.md) | 019,031 | 11 |
| 034 | [WeatherBench 2 ingestion planning](034_weatherbench2_ingestion.md) | 020,031 | 12 |
| 035 | [ERA5 verification-only rules](035_era5_verification_only.md) | 020,031 | 13 |
| 036 | [Reference-analysis uncertainty](036_reference_analysis_uncertainty.md) | 035 | 14 |
| 037 | [Raw-file manifests and checksums](037_raw_manifests_checksums.md) | 033,034 | 15 |
| 038 | [Zarr and NetCDF field storage](038_zarr_netcdf_storage.md) | 033,034,037 | 16 |
| 039 | [Parquet feature and label tables](039_parquet_feature_labels.md) | 038,052 | 17 |
| 040 | [PostgreSQL metadata and provenance boundaries](040_postgres_metadata_provenance.md) | 037,039 | 18 |
| 041 | [Canonical harmonization](041_canonical_harmonization.md) | 033,034,035 | 19 |
| 042 | [Issue time, valid time, and lead time](042_issue_valid_lead_time.md) | 041 | 20 |
| 043 | [Grid, coordinate, and unit alignment](043_grid_coordinate_units.md) | 041,042 | 21 |
| 044 | [Ensemble member completeness](044_ensemble_completeness.md) | 041,043 | 22 |

## Recommended study order

Read the assigned files in numeric order unless a prerequisite is listed. Before team discussion, check the index, record all unverified claims, and do not upgrade targets to results. Each study should produce the handoff named in the file.

## Short daily plan

Day 1: Read the first third of the allocation and record vocabulary and evidence labels.  
Day 2: Read the middle third and complete the practical exercises for the most foundational files.  
Day 3: Read the final third and connect outputs to the next member’s allocation.  
Day 4: Audit claims, dependencies, and the public-proxy/NCMRWF boundary.  
Day 5: Prepare a five-minute presentation and one unresolved question for the team.

## Discussion questions

1. Which statements are confirmed, and which remain literature leads, project decisions, targets, gaps, or future work?
2. Does any planned demo or document imply trained/evaluated performance or NCMRWF operational validation?
3. What evidence does the next member need from this allocation?
4. Which question should enter the shared cross-team question register?

## Concrete team handoff

Provide a concise synthesis for the team covering the research-novelty, data-governance, QC, and alignment presenter, a table of evidence labels, completed exercises, unresolved questions, and links to all assigned files. Member 2 must use the exact terminology and caveats from the package README.
